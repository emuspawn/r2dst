package ai.ais;

import owner.Owner;
import world.BuildEngineOverlay;
import pathFinder.PathFinder;
import driver.GameEngineOverlay;
import ai.AI;
import java.util.ArrayList;
import java.util.Random;
import key.keys.*;

import world.unit.*;
import utilities.Location;

public class SteamRollAI extends AI
{
	private double bEscrow = 0, uEscrow = 0;
	private double uEscrowPercent = 0;
	private double bEscrowPercent = 0;
	private double gained, tempres = getResources();
	Random rand = new Random();
	double startx = 0, starty = 0, sidex = 1, sidey = 1;
	Location enemyBase = new Location(0,0);
	int deaths = 0;
	int population, popmax, headroom;
	ArrayList<FriendlyUnitMask> fighterList = new ArrayList<FriendlyUnitMask>();
	
	public SteamRollAI(Owner o, GameEngineOverlay geo, BuildEngineOverlay beo, PathFinder pf)
	{
		super(o, geo, beo, pf);
	}
	
	public void performAIFunctions()
	{		
		ArrayList<FriendlyUnitMask> u = geo.getFriendlyUnits(o);
		ArrayList<EnemyUnitMask> eu = geo.getVisibleEnemyUnits(o);
		ArrayList<Location> l = geo.getVisibleResources(o);
		int workers = 0, barracks = 0, fighters = 0, hqs = 0;
		if (startx == 0 && starty == 0)
			checkForStart();
		for(int i = 0; i < u.size(); i++)
		{
			if(u.get(i).getName().equalsIgnoreCase("barracks1"))
				barracks++;
			if(u.get(i).getName().equalsIgnoreCase("worker1"))
				workers++;
			if(u.get(i).getName().equalsIgnoreCase("fighter1"))
				fighters++;
			if(u.get(i).getName().equalsIgnoreCase("hq1"))
				hqs++;
		}
		
		//Resource management
		gained = getResources() - tempres;
		tempres = getResources();
		
		if (gained > 0)
		{
			uEscrow += gained*(uEscrowPercent/100);
			bEscrow += gained*(bEscrowPercent/100);
		}
		
		population = barracks+fighters+workers;
		popmax = hqs*10;
		headroom = popmax - population;
		
		bEscrowPercent = 0;
		uEscrowPercent = 0;
		if (workers < 6)
			bEscrowPercent = 0;
		if (workers > 5 && barracks < 1)
			bEscrowPercent = 100;
		if (hqs > 1)
		{
			bEscrowPercent = 0;
			uEscrowPercent = 20;
		}
		if (barracks > 0)
		{
			uEscrowPercent = 20;
			bEscrow = 0;
		}
		if (headroom <= 1)
		{
			bEscrowPercent = 100;
			uEscrowPercent = 0;
		}
		
		
		//Code to find nearest enemy target
		enemyBase = new Location(0.0,0.0);
		double dist = 999999;
		int closest = 0;
		Location myLoc = new Location(startx, starty);
		for (int i = 0; i < eu.size(); i++)
		{
			if (eu.get(i).isBuilding())
			{
				Location loc = eu.get(i).getLocation();
				if (myLoc.distanceTo(loc) < dist)
				{
					dist = myLoc.distanceTo(loc);
					closest = i;
				}
			}
		}
		//Targets units if no buildings visible
		if (dist != 999999)
			enemyBase = eu.get(closest).getLocation();
		else
		{
			for (int i = 0; i < eu.size(); i++)
			{
				Location loc = eu.get(i).getLocation();
				if (myLoc.distanceTo(loc) < dist)
				{
					dist = myLoc.distanceTo(loc);
					closest = i;
				}
			}
		}
		if (dist != 999999)
			enemyBase = eu.get(closest).getLocation();
		
		//Unit behaviors
		for (int i = 0; i < u.size(); i++)
		{
			if (u.get(i).getName().equalsIgnoreCase("worker1"))
			{
				boolean done = false; 
				
				//HQs over barracks
				if (getWithoutBuildingEscrow() >= 22.0 && headroom < (hqs+1)/2 && (barracks > 0 || hqs == 0) && headroom < 10)
				{
					done = buildAt("hq1", u.get(i), randomizeLoc(getBuildingPos(hqs)));
					if (done) 
					{
						releaseBEscrow(22.0);
						hqs++;
					}
				}
				if (((barracks < hqs-1) || barracks == 0) && barracks < 2 && !done && getWithoutBuildingEscrow() >= 15.0)
				{
					done = buildAt("barracks1", u.get(i), randomizeLoc(getBuildingPos(barracks)));
					if (done) 
					{
						releaseBEscrow(15.0);
						barracks++;
					}
				}
				if (!done && l != null)
				{
					//if it cant build, gather
					gatherClosestResource(u.get(i), l);
				}
				else if (l == null)
				{
					//if no resources visible, explore
					moveUnit(u.get(i), new Location(startx-200+rand.nextInt(400), starty-200+rand.nextInt(400)));
				}
			}
			else if (u.get(i).getName().equalsIgnoreCase("fighter1"))
			{
				//seeks out targeted enemy unit/building
				if (enemyBase.x == 0.0 && enemyBase.y == 0.0)
				{
					double x = rand.nextInt(geo.getMapWidth());
					double y = rand.nextInt(geo.getMapHeight());
					moveUnit(u.get(i), new Location(x, y));
				}
				else //move randomly
				{
					double x = enemyBase.x - 50 + rand.nextInt(100);
					double y = enemyBase.y - 50 + rand.nextInt(100);
					moveUnit(u.get(i), new Location(x, y));
				}
			}
			else if (u.get(i).getName().equalsIgnoreCase("barracks1"))
			{
				if (getWithoutUnitEscrow() >= 6)
				{
					build("fighter1", u.get(i));
					releaseUEscrow(6);
				}
			}
			else if (u.get(i).getName().equalsIgnoreCase("hq1"))
			{
				if (getResources() >= 5 && (workers < 6 || fighters > 2))
					build("worker1", u.get(i));
			}
		}
	}
	
	
	//Placement of various buildings
	private Location getBuildingPos(int buildings)
	{
		Location l = null;
		int w = geo.getMapWidth();
		int h = geo.getMapHeight();
		
		switch(buildings)
		{
			case 0:
			l = new Location(startx, starty);
			break;
			
			case 1:
			l = new Location((w/2) + (((startx - (w/2))*-sidex)/2)*-sidex, (h/2) + (((starty - (h/2))*-sidey)/2)*-sidey);
			break;
			
			case 2:
			l = new Location((w/2) + (startx-(w/2))*-sidex, h/2);
			break;
			
			case 3:
			l = new Location(w/2, (h/2) + (starty-(h/2))*-sidey);
			break;
			
			case 4:
			l = new Location(w/2, h/2);
			break;
			
			case 5:
			l = new Location((w/2) + ((w/5)*-sidex), h/2);
			break;
				
			case 6:
			l = new Location(w/2, (h/2) + ((h/4)*-sidey));
			break;
			
			default:
			l = new Location(rand.nextInt(w),rand.nextInt(h));
			break;		
		}
		return l;
	}
	
	
	/*	Resource Management System
	 *	building and unit escrow
	 */
	private double getResources()
	{
		return o.getResourceCount("green circle")-uEscrow-bEscrow;
	}
	
	private double getWithoutBuildingEscrow()
	{
		return o.getResourceCount("green circle")-uEscrow;
	}
	
	private double getWithoutUnitEscrow()
	{
		return o.getResourceCount("green circle")-bEscrow;
	}
	
	private void releaseBEscrow(double minus)
	{
		bEscrow -= minus;
		if (bEscrow < 0)
			bEscrow = 0;
	}
	
	private void releaseUEscrow(double minus)
	{
		uEscrow -= minus;
		if (uEscrow < 0)
			uEscrow = 0;
	}
	
	
	//Used to mix up the locations of stuff
	private Location randomizeLoc(Location l)
	{
		double x = l.x;
		double y = l.y;
		x = x - (geo.getMapWidth()/10) + rand.nextInt(200);
		y = y - (geo.getMapHeight()/10) + rand.nextInt(200);
		return new Location(x,y);
	}
	
	//Find start location
	public void checkForStart()
	{
		ArrayList<FriendlyUnitMask> u = geo.getFriendlyUnits(o);
		for(int i = 0; i < u.size(); i++)
		{
			if(u.get(i).getName().equalsIgnoreCase("hq1"))
			{
				Location f = u.get(i).getLocation();
				startx = f.x;
				starty = f.y;
				if (startx < geo.getMapWidth()/2)
					sidex = -1;
				if (starty < geo.getMapHeight()/2)
					sidey = -1;
				System.out.println("" + startx + " " + starty);
				break;
			}
		}
	}
}
